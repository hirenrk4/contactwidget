<?php

namespace Solwin\Contactwidget\Model;

class Contact extends \Magento\Framework\Model\AbstractModel
{

    public function _construct()
    {
        $this->_init('Solwin\Contactwidget\Model\ResourceModel\Contact');
    }
}
