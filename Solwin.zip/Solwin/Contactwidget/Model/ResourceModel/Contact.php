<?php

namespace Solwin\Contactwidget\Model\ResourceModel;

class Contact extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    public function _construct()
    {
        $this->_init('solwin_contactwidget_contact', 'contact_id');
    }
}
