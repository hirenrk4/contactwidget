<?php

namespace Solwin\Contactwidget\Model\ResourceModel\Contact;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    public function _construct()
    {
        $this->_init(
            'Solwin\Contactwidget\Model\Contact',
            'Solwin\Contactwidget\Model\ResourceModel\Contact'
        );
    }
}
