<?php
/**
 * Solwin Infotech
 * Solwin Contact Form Widget Extension
 *
 * @category   Solwin
 * @package    Solwin_Contactwidget
 * @copyright  Copyright © 2006-2016 Solwin (https://www.solwininfotech.com)
 * @license    https://www.solwininfotech.com/magento-extension-license/
 */
namespace Solwin\Contactwidget\Model\Config\Source;

class Multiselect implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            ['value' => 'category-page', 'label' => __('Category Page')],
            ['value' => 'product-page', 'label' => __('Product Page')],
            ['value' => 'cart-page', 'label' => __('Cart Page')]];
    }
}
