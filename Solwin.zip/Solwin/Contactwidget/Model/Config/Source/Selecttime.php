<?php
/**
 * Solwin Infotech
 * Solwin Contact Form Widget Extension
 *
 * @category   Solwin
 * @package    Solwin_Contactwidget
 * @copyright  Copyright © 2006-2016 Solwin (https://www.solwininfotech.com)
 * @license    https://www.solwininfotech.com/magento-extension-license/
 */
namespace Solwin\Contactwidget\Model\Config\Source;

class Selecttime implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            ['value' => 'Morning', 'label' => __('Morning')],
            ['value' => 'Afternoon', 'label' => __('Afternoon')],
            ['value' => 'Evening', 'label' => __('Evening')],
            ['value' => 'Anytime', 'label' => __('Anytime')]];
    }
}
